# SYMBY PICK — web 0.2

Lokální prototyp. Není investiční doporučení.

## Spuštění
Otevři `index.html` v prohlížeči (Chrome / Safari). Logo musí zůstat ve stejné složce (`logo.jpg`).

## Flow
Trh (USA / Evropa / UK) + Sídlo|Burza → P/E 0–10 / 10–20 / 20–30 → sektor → picky.

Bez P/E se titul neukáže. Marže / rozvaha může být `—`.
Rok z TradingView, jinak měsíc z eToro.
Řazení default P/E vzestupně, šipka u sloupce.

## Data
- Cena, týden, měsíc: eToro quote 18. 9. 2026
- P/E: veřejné TTM / TV snapshot (ne live feed)
- LSE ceny na kartě v GBP (eToro posílá pence)

## Co toto ještě není
Celý eToro vesmír, oficiální TradingView API, eToro Builders recenze, App Store.

## Nasazení na web
1. GitHub repo → nahraj tuhle složku
2. Settings → Pages → Deploy from branch `/`
3. Otevře se `index.html`
